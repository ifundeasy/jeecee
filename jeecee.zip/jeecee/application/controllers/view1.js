/**
 * Created by rappresent on 4/4/14.
 */
define(['jeecee'], function (app) {
	app.register.controller('View1Ctrl', function ($scope) {
		$scope.message = "Message from View1Ctrl";
	});
});
